package com.puxun;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class callback
 */
public class callback extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public callback() {
        super();
        // TODO Auto-generated constructor stub
    }

 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out = response.getWriter();
		
		String Key = "";								//�̻���Կ
        String p1_MerId = "";							//�̻�ID
        String r0_Cmd = request.getParameter("r0_Cmd");
        String r1_Code = request.getParameter("r1_Code");
        String r2_TrxId = request.getParameter("r2_TrxId");	//ƽ̨��ˮ��
        String r3_Amt = request.getParameter("r3_Amt");		//֧�����
        String r4_Cur = request.getParameter("r4_Cur");
        String r5_Pid = request.getParameter("r5_Pid");
        String r6_Order =request.getParameter("r6_Order");	//�̻�������
        String r7_Uid = request.getParameter("r7_Uid");
        String r8_MP = request.getParameter("r8_MP");
        String r9_BType = request.getParameter("r9_BType");  //֪ͨ���� 1ͬ��֪ͨ 2�첽֪ͨ
        String rp_PayDate = request.getParameter("rp_PayDate");
        String hmac = request.getParameter("hmac");			//����ǩ��


        String sbOld = "";
        sbOld += p1_MerId;
        sbOld += r0_Cmd;
        sbOld += r1_Code;
        sbOld += r2_TrxId;
        sbOld += r3_Amt;
        sbOld += r4_Cur;
        sbOld += r5_Pid;
        sbOld += r6_Order;
        sbOld += r7_Uid;
        sbOld += r8_MP;
        sbOld += r9_BType;   

        String nhmac = DigestUtil.hmacSign(sbOld, Key); //����ǩ��
        if (nhmac.equals( hmac)) {
            if ("1".equals(r1_Code)) {           	
            	//֧���ɹ�,�봦���Լ����߼� ��ע��֪ͨ���ܻ��� ������ظ�����
                
            	if ( "1".equals(r9_BType)) {  //ͬ��֪ͨ  �����߼���ͬʱ����
                	out.print("SUCCESS֧���ɹ�!<br>��ƷID:" + r5_Pid + "<br>�̻�������:" + r6_Order + "<br>֧�����:" + r3_Amt + "<br>֧��������ˮ��:" + r2_TrxId + "<BR>");
                }
                else if (r9_BType == "2") {  //�첽֪ͨ
                	out.print("SUCCESS");
                }
            }
            else {               
            	out.print("֧��ʧ��!");
            }
        }
        else {      
        	out.print("ǩ��ʧ��");
        }
    }
}
