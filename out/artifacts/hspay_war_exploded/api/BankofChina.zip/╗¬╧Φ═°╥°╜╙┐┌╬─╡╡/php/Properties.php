<?php

/*
 * @Description 华翔网络产品通用接口范例 
 * @V3.0
 * @Author rui.xin
 */

#	商户编号p1_MerId,以及密钥merchantKey 需要联系QQ：3002924736，请在商户平台里获取
$p1_MerId			= "1111111";                                    #测试使用  商户平台的商户ID
$merchantKey	= "1111111111111111111111111111111111111111";		#测试使用  商户平台的商户KEY

$logName	= "BANK_HTML.log";

?> 