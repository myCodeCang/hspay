﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

        if (Request.HttpMethod == "POST") {

            String PostUrl = "http://k.miaojiesuan.net/hspay/node";//请查看接口文档，或询问客服
            String p0_Cmd = "Buy";// 业务类型 是  Max(20)  固定值“Buy” . 1 

            string p1_MerId = System.Configuration.ConfigurationManager.AppSettings["p1_MerId"];// 商户编号 是  Max(11)  商户平台的商户ID
            string key = System.Configuration.ConfigurationManager.AppSettings["Key"];          //商户密钥    商户平台的商户KEY

            String p2_Order = Request["p2_Order"] + "";//  商户订单号 是  Max(50) 若不为””，提交的订单号必须在自身账户交易中唯一;为 ””
            String p3_Amt = Request["p3_Amt"] + "";//支付金额 是  Max(20)  单位:元，精确到分.此参数为空则无法直连(如直连会报错：抱歉，交易金额太小。),必须到易宝网关让消费者输入金额 4 
            String p4_Cur = "CNY";//  交易币种 是  Max(10)  固定值 ”CNY”. 5 
            String p5_Pid = "";// 商品名称 是  Max(20) 用于支付时显示在易宝支付网关左侧的订单产品信息.
            String p6_Pcat = "";// 商品种类 是  Max(20)  商品种类.
            String p7_Pdesc = ""; //商品描述 是  Max(20)  商品描述.
            String p8_Url = "http://localhost/CallBack.aspx";// 商户接收支付成功数据的地址 是  Max(200) 支付成功后易宝支付会向该地址发送两次成功通知
            String pa_MP = "";// 商户扩展信息 是  Max(200)  返回时原样返回，此参数如用到中文，请注意转码. 11 
            String pd_FrpId = Request["pd_FrpId"] + "";  //支付通道编码 否  Max(50) 默认为 ”” ，到易宝支付网关，易宝支付网关默认显示已开通的全部支付通道.
            String pr_NeedResponse = ""; // 应答机制 是  Max(1) 固定值为“1”: 需要应答机制; 收到易宝支付服务器点对点支付成功通知，必须回写以”success”（无关大小写）开头的字符串，即使您收到成功通知时发现该订单已经处理过，也要正确回写”success”，否则易宝支付将认为您的系统没有收到通知，启动重发机制，直到收到”success”为止。 
            String hmac = "";// 签名数据    Max(32) 产生hmac需要两个参数，并调用相关API.


            string sbOld = "";
            sbOld += p0_Cmd;
            sbOld += p1_MerId;
            sbOld += p2_Order;
            sbOld += p3_Amt;
            sbOld += p4_Cur;

            sbOld += p5_Pid;
            sbOld += p6_Pcat;
            sbOld += p7_Pdesc;
            sbOld += p8_Url;

            sbOld += pa_MP;
            sbOld += pd_FrpId;
            sbOld += pr_NeedResponse;

            hmac = fox163.net.Encrypt.HmacSign(sbOld, key);

            string result = "";
            result += PostUrl;
            result += "?p0_Cmd=" + p0_Cmd;
            result += "&p1_MerId=" + p1_MerId;
            result += "&p2_Order=" + HttpUtility.UrlEncode(p2_Order, System.Text.Encoding.GetEncoding("gb2312"));
            result += "&p3_Amt=" + p3_Amt;
            result += "&p4_Cur=" + p4_Cur;
            result += "&p5_Pid=" + HttpUtility.UrlEncode(p5_Pid, System.Text.Encoding.GetEncoding("gb2312"));
            result += "&p6_Pcat=" + HttpUtility.UrlEncode(p6_Pcat, System.Text.Encoding.GetEncoding("gb2312"));
            result += "&p7_Pdesc=" + HttpUtility.UrlEncode(p7_Pdesc, System.Text.Encoding.GetEncoding("gb2312"));
            result += "&p8_Url=" + HttpUtility.UrlEncode(p8_Url, System.Text.Encoding.GetEncoding("gb2312"));
            result += "&pa_MP=" + HttpUtility.UrlEncode(pa_MP, System.Text.Encoding.GetEncoding("gb2312"));
            result += "&pd_FrpId=" + pd_FrpId;
            result += "&pr_NeedResponse=" + pr_NeedResponse;
            result += "&hmac=" + hmac;

            Response.Redirect(result);
        }
    }
}