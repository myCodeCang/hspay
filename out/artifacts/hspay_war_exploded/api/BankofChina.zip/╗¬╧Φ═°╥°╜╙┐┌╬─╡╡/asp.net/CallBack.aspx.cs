﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CallBack : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {

        string Key = System.Configuration.ConfigurationManager.AppSettings["Key"];
        string p1_MerId = System.Configuration.ConfigurationManager.AppSettings["p1_MerId"];
        string r0_Cmd = Request["r0_Cmd"];
        string r1_Code = Request["r1_Code"];
        string r2_TrxId = Request["r2_TrxId"];
        string r3_Amt = Request["r3_Amt"];
        string r4_Cur = Request["r4_Cur"];
        string r5_Pid = Request["r5_Pid"];
        string r6_Order = Request["r6_Order"];
        string r7_Uid = Request["r7_Uid"];
        string r8_MP = Request["r8_MP"];
        string r9_BType = Request["r9_BType"];
        string rp_PayDate = Request["rp_PayDate"];
        string hmac = Request["hmac"];


        string sbOld = "";
        sbOld += p1_MerId;
        sbOld += r0_Cmd;
        sbOld += r1_Code;
        sbOld += r2_TrxId;
        sbOld += r3_Amt;
        sbOld += r4_Cur;
        sbOld += r5_Pid;
        sbOld += r6_Order;
        sbOld += r7_Uid;
        sbOld += r8_MP;
        sbOld += r9_BType;

        string nhmac = fox163.net.Encrypt.HmacSign(sbOld, Key);
        if (nhmac == hmac) {
            if (r1_Code == "1") { //支付成功,请处理自己的逻辑
                if (r9_BType == "1") {  //同步通知  两者逻辑可同时处理
                    Response.Write("SUCCESS支付成功!<br>商品ID:" + r5_Pid + "<br>商户订单号:" + r6_Order + "<br>支付金额:" + r3_Amt + "<br>支付交易流水号:" + r2_TrxId + "<BR>");
                }
                else if (r9_BType == "2") {  //异步通知
                    Response.Write("SUCCESS");
                }
            }
            else {
                Utils.logstr(r6_Order, "支付失败", hmac);
                Response.Write("支付失败!");
            }
        }
        else {
            Utils.logstr(r6_Order, "签名失败", hmac);
            Response.Write("签名失败");
        }
    }
}